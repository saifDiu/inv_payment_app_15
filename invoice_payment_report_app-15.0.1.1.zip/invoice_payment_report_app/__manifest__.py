# -*- coding: utf-8 -*-

{
    'name': 'SalesPerson Wise Invoice Payment Report',
    "author": "Edge Technologies",
    'version': '15.0.1.1',
    'live_test_url': "https://youtu.be/Sj8iEPu4hoU",
    "images":['static/description/main_screenshot.png'],
    'summary': 'Invoices payment reports vendor bill payment reports SalesPerson Wise bill Payment Report for customer invoice report invoice payment filter report account payment report invoice statement report for payment invoice report for salesperson invoice report',
    'description': """
        invoices and bills,sales person wise payment information
    """,
    "license" : "OPL-1",
    'depends': ['sale', 'purchase', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'report/report.xml',
        'report/payment_report.xml',
        'views/invoice_payment_report.xml', 
    ],
    'installable': True,
    'auto_install': False,
    'price': 15,
    'currency': "EUR",
    'category': 'Accounting',
}
