# -*- coding: utf-8 -*-

from odoo import api, fields, models,_
from odoo.exceptions import UserError, ValidationError
import xlsxwriter
from datetime import datetime
import base64
import io
from io import BytesIO

class InheritResUsers(models.Model):
	_inherit="res.users"

	is_salesperson=fields.Boolean(string="Salesperson Field In Invoice Payment Report")
	is_show=fields.Boolean(default=False)


class InvoicePaymentReport(models.TransientModel):
	_name="invoice.payment_report"
	_description="Invoice Payment Report"

	start_date=fields.Date(string="Start Date")
	end_date=fields.Date(string="End Date",default=fields.Date.today)
	status=fields.Selection([("all","All"),("paid","Posted/Paid"),("not_paid","Posted/Not Paid"), ('partial', 'Partially Paid')],string="Status",default="all")
	file=fields.Binary("Download File")
	file_name = fields.Char(string="File Name")

	user_ids=fields.Many2many("res.users",string="Salesperson")
	customer_invoices=fields.One2many("invoice.payment_report", "name")

	name=fields.Char("number")
	number=fields.Char("invoice number")
	date=fields.Date("date")
	sales_person=fields.Char("sale person")
	company=fields.Char("company")

	payment_type=fields.Char("payment method")
	amount=fields.Float("amount", default=0.0)
	payment_date=fields.Date("payment date")
	memo_number=fields.Char("memo number")
	total=fields.Float("total amount", default=0.0)
	customer=fields.Char("customer")
	person_total=fields.One2many("invoice.payment_report","number")

	bank=fields.Float("total bank", default=0.0)
	cash=fields.Float("total cash", default=0.0)

	# pdf report
	def print_pdf(self):

		if self.start_date==False:
			raise UserError(
					_('Enter Start date and End date.'))

		elif self.end_date==False:
			self.end_date=str(datetime.today())

		elif not self.user_ids:
			raise UserError(
					_('Select atleast one Salesperson.'))

		vals={};lst=[];memo_dict={};amount_dict={};tot_dict={};total_list=[]

		payment_ids =self.env["account.payment"].search([])

		for user in self.user_ids:
			for line in payment_ids:
				for record in line.reconciled_invoice_ids:
					if user.id == record.invoice_user_id.id:
						if record.invoice_date >= self.start_date and record.invoice_date <= self.end_date:
							if record.payment_state == self.status:
								payment_method=line.journal_id.type
								amount=line.amount
								if line.id not in vals.keys():
									vals.update({
										line.id:
										{
											'name':record.name or "In draft",
											'number':record.name or "In draft",
											'date':record.invoice_date,
											'sales_person':record.user_id.name,
											'company':record.partner_id.name,
											'payment_type':payment_method,
											'amount':amount,
											'payment_date':line.date,
											'memo_number':line.name
										}
									})
									memo_dict.update({
										line.id : [0,0,vals[line.id]]
									})
									if record.user_id.name not in amount_dict:
										amount_dict.update({
											record.user_id.name:{
												'total':amount
											}
										})
									else:
										amount_dict[record.user_id.name]['total']+=amount

									if payment_method not in tot_dict:
										tot_dict[payment_method]=amount
									else:
										tot_dict[payment_method]+=amount
							if self.status =="all":
								payment_method=line.journal_id.type
								amount=line.amount
								if line.id not in vals.keys():
									vals.update({
										line.id:
										{
											'name':record.name or "In draft",
											'number':record.name or "In draft",
											'date':record.invoice_date,
											'sales_person':record.user_id.name,
											'company':record.partner_id.name,
											'payment_type':payment_method,
											'amount':amount,
											'payment_date':line.date,
											'memo_number':line.name
										}
									})
									memo_dict.update({
										line.id : [0,0,vals[line.id]]
									})
									if record.user_id.name not in amount_dict:
										amount_dict.update({
											record.user_id.name:{
												'total':amount
											}
										})
									else:
										amount_dict[record.user_id.name]['total']+=amount

									if payment_method not in tot_dict:
										tot_dict[payment_method]=amount
									else:
										tot_dict[payment_method]+=amount

		for memo in memo_dict.values():
			lst.append(memo)

		self.write({
			'customer_invoices':lst
		})

		for person in amount_dict:
			total_list.append((0,0,{
				'customer':person,
				'total':amount_dict[person]['total']
			}))
		self.write({'person_total':total_list})

		for method in tot_dict:
			self.write({
				method:tot_dict[method]
			})

		res=self.env.ref('invoice_payment_report_app.pdf_payment_invoice').report_action(self)
		res.update({'close_on_report_download': True})
		return res

	#xls report
	def print_xls(self):

		if self.start_date==False:
			raise UserError(
					_('Please Enter Start Date.'))
		elif self.end_date==False:
			self.end_date=str(datetime.today())

		elif not self.user_ids:
			raise UserError(
					_('Select atleast one Salesperson.'))

		payment_ids =self.env["account.payment"].search([])


		name_of_file = 'Invoice Payment Information.xls'
		file_path = 'Invoice Payment Information' + '.xls'
		workbook = xlsxwriter.Workbook('/tmp/'+file_path)
		worksheet = workbook.add_worksheet('Invoice Payment Information')
		title = "Invoice Payment Report"
		date=str(self.start_date) +" to "+str(self.end_date)

		bold = workbook.add_format({'bold': True})
		align_left = workbook.add_format({'align': 'center'})
		merge_format = workbook.add_format({
			'bold': 1,
			'border': 1,
			'align': 'center',
			'valign': 'vcenter',
			'fg_color': 'gray',})

		cell_format=workbook.add_format({
			'bold':1,
			'align':'center',
			'fg_color':'gray',
			})

		date_format = workbook.add_format({'num_format':'dd/mm/yy'})

		worksheet.set_column(0, 0, 20)
		worksheet.set_column(0, 1, 23)
		worksheet.set_column(0, 2, 20)
		worksheet.set_column(0, 3, 15)
		worksheet.set_column(0, 4, 15)
		worksheet.set_column(0, 5, 15)

		worksheet.set_row(0,30)

		worksheet.merge_range('A1:G1', title, merge_format)
		worksheet.merge_range('A2:G2', date, merge_format)

		row=4;
		var_total={'tot':0,'tot_bank':0,'tot_cash':0,'tot_test':0}
		for user in self.user_ids:
			new_dict={'bank':0,'cash':0,'total':0,'test':0}
			user_id = "Sales Person : "+ user.name
			worksheet.merge_range(row,0,row,6,user_id, merge_format)
			worksheet.write(row+2,0,"Invoice",cell_format)
			worksheet.write(row+2,1,"Invoice Date",cell_format)
			worksheet.write(row+2,2,"Sales person",cell_format)
			worksheet.write(row+2,3,"Customer",cell_format)
			worksheet.write(row+2,4,"Bank",cell_format)
			worksheet.write(row+2,5,"Cash",cell_format)
			worksheet.write(row+2,6,"Total",cell_format)
			row+=3
			user_data = {}
			for line in payment_ids:
				for data in line.reconciled_invoice_ids:
					start = datetime.strptime(str(self.start_date), '%Y-%m-%d')
					in_date = datetime.strptime(str(data.invoice_date), '%Y-%m-%d')
					end = datetime.strptime(str(self.end_date),'%Y-%m-%d')
					if user.id == data.invoice_user_id.id:
						if in_date >= start and in_date <= end:
							if data.payment_state == self.status:
								payment_method={'bank':0,'cash':0,'tot':0}
								pay = line.journal_id.type
								user_data['number'] = data.name
								user_data['date'] = data.invoice_date
								user_data['sales_person'] = data.user_id.name
								user_data['customer'] = data.partner_id.name
								if pay in "bank":
									var_total['tot']+=line.amount
									var_total['tot_bank']+=line.amount
									new_dict['total'] += line.amount
									new_dict['bank'] += line.amount
									payment_method['bank']=payment_method['bank']+line.amount
								elif pay in "cash":
									var_total['tot']+=line.amount
									var_total['tot_cash']+=line.amount
									new_dict['total'] += line.amount
									new_dict['cash']+= line.amount
									payment_method['cash']=payment_method['cash']+line.amount
								worksheet.write(row,0,user_data['number'])
								worksheet.write(row,1,user_data['date'],date_format)
								worksheet.write(row,2,user_data['sales_person'])
								worksheet.write(row,3,user_data['customer'])
								worksheet.write(row,4,payment_method['bank'])
								worksheet.write(row,5,payment_method['cash'])
								worksheet.write(row,6,payment_method['bank']+payment_method['cash'])
								row+=1

							elif self.status in "all":
								payment_method={'bank':0,'cash':0,'tot':0}
								pay = line.journal_id.type
								user_data['number'] = data.name
								user_data['date'] = line.date
								user_data['sales_person'] = data.user_id.name
								user_data['customer'] = data.partner_id.name
								if pay in "bank":
									var_total['tot']+=line.amount
									var_total['tot_bank']+=line.amount
									new_dict['total'] += line.amount
									new_dict['bank'] += line.amount
									payment_method['bank']=payment_method['bank']+line.amount
								elif pay in "cash":
									var_total['tot']+=line.amount
									var_total['tot_cash']+=line.amount
									new_dict['total'] += line.amount
									new_dict['cash']+= line.amount
									payment_method['cash']=payment_method['cash']+line.amount
								worksheet.write(row,0,user_data['number'])
								worksheet.write(row,1,user_data['date'],date_format)
								worksheet.write(row,2,user_data['sales_person'])
								worksheet.write(row,3,user_data['customer'])
								worksheet.write(row,4,payment_method['bank'])
								worksheet.write(row,5,payment_method['cash'])
								worksheet.write(row,6,payment_method['bank']+payment_method['cash'])
								row+=1

							

			worksheet.write(row,3,"Total",bold)
			worksheet.write(row,4,new_dict['bank'])
			worksheet.write(row,5,new_dict['cash'])
			worksheet.write(row,6,new_dict['total'])
			row+=2

		worksheet.merge_range(row,0,row,1,"Payment Method", merge_format)
		worksheet.write(row+1,0,"Name",cell_format)
		worksheet.write(row+1,1,"Total",cell_format)
		row+=2
		worksheet.write(row,0,"Bank")
		worksheet.write(row,1,var_total['tot_bank'])
		worksheet.write(row+1,0,"Cash")
		worksheet.write(row+1,1,var_total['tot_cash'])
		worksheet.write(row+2,0,"Total")
		worksheet.write(row+2,1,var_total['tot'])


		workbook.close()
		export_id = base64.b64encode(open('/tmp/' + file_path, 'rb+').read())
		result_id = self.env['invoice.payment_report'].create({'file': export_id ,'file_name': name_of_file})
		return {
				'name': 'Invoice Payment Report',
				'view_mode': 'form',
				'res_id': result_id.id,
				'res_model': 'invoice.payment_report',
				'view_type': 'form',
				'type': 'ir.actions.act_window',
				'target': 'new',
			}
