# -*- coding: utf-8 -*-

from . import invoice_payment_report
